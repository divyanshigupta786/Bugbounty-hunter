#!/bin/bash
pytest tests/test_reproduction_candidate.py -v
